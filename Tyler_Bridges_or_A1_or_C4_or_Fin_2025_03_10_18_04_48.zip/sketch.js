let hue = 80;

function sky() {
  if (mouseX >= 200) {
    background("purple");
  } else if (mouseX <= 200) {
    background("hotpink");
  }
}

function setup() {
  createCanvas(400, 400);
}
sky();

function draw() {
  sky();

  let x = 40;
  let y = 40;
  let s = 80;

  //Initial
  fill(`hsla( ${276 + hue}, 100%, 20%, 1)`);

  //Top row
  ellipse(x, y, s);
  ellipse(x + 80, y, s);
  ellipse(x + 160, y, s);
  ellipse(x + 240, y, s);
  ellipse(x + 320, y, s);

  //Stem
  fill(`hsla( ${276 + hue}, 67%, 28%, 1)`);
  ellipse(x + 160, y + 80, s);

  fill(`hsla( ${276 + hue}, 56%, 36%, 1)`);
  ellipse(x + 160, y + 160, s);

  fill(`hsla( ${276 + hue}, 49%, 44%, 1)`);
  ellipse(x + 160, y + 240, s);
  fill(`hsla( ${276 + hue}, 42%, 56%, 1)`);

  ellipse(x + 160, y + 320, s);

  //Background
  //Row 1
  fill(`hsla( ${194 + hue}, 100%, 29%, 1)`);

  ellipse(x, y + 80, s);
  ellipse(x + 80, y + 80, s);
  ellipse(x + 240, y + 80, s);
  ellipse(x + 320, y + 80, s);

  //Row 2
  fill(`hsla( ${200 + hue}, 100%, 27%, 1)`);

  ellipse(x, y + 160, s);
  ellipse(x + 80, y + 160, s);
  ellipse(x + 240, y + 160, s);
  ellipse(x + 320, y + 160, s);

  //Row 3
  fill(`hsla( ${212 + hue}, 58%, 28%, 1)`);

  ellipse(x, y + 240, s);
  ellipse(x + 80, y + 240, s);
  ellipse(x + 240, y + 240, s);
  ellipse(x + 320, y + 240, s);

  //Row 4
  fill(`hsla( ${232 + hue}, 35%, 24%, 1)`);

  ellipse(x + 80, y + 320, s);
  ellipse(x, y + 320, s);
  ellipse(x + 240, y + 320, s);
  ellipse(x + 320, y + 320, s);
}

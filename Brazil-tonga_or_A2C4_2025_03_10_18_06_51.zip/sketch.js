function setup() {
  createCanvas(600, 400);
}

function draw() {
  background("red");
  rect(0, 0, 600, 200)
  fill("darkgreen")
  brazil();
  fill("blue")
  brazil(0, 0, 0.5);
  brazil(300, 0, 0.5);
  brazil(0, 200, 0.5);
  brazil(300, 200, 0.5);
  fill("blue")
  tongaplus();
  fill("darkgreen")
  tongaplus(0,0,0.5)
  tongaplus(300, 0, 0.5)
  tongaplus(0, 200, 0.5)
  tongaplus(300, 200, 0.5)
  
  
}

function brazil(x, y, size) {
  push();
  translate(x, y);
  scale(size);
  beginShape();
  vertex(150, 200);
  vertex(300, 100);
  vertex(450, 200);
  vertex(300, 300);
  vertex(150, 200);
  endShape();
  pop();
}

function tongaplus(x, y, size){
  push()
  translate(x, y)
  scale(size)
  beginShape()
  vertex(280, 150)
  vertex(320, 150)
  vertex(320, 180)
  vertex(350, 180)
  vertex(350, 220)
  vertex(320, 220)
  vertex(320, 250)
  vertex(280, 250)
  vertex(280, 220)
  vertex(250, 220)
  vertex(250, 180)
  vertex(280,180)
  vertex(280, 150)
  endShape()
  pop()
  
}
